package com.project.zara.service;

import java.util.List;

import com.project.zara.model.Test;

public interface TestService {
	public List<Test> getTest();
}
